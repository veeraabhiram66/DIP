import streamlit as st
import cv2
import dlib
import numpy as np

# Load the face detector and landmark predictor
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

def empty():
    pass
    
def createBox(img, points, scale=5, masked=False, cropped=True):
    if masked:
        mask = np.zeros_like(img)
        mask = cv2.fillPoly(mask, [points], (255, 255, 255))
        img = cv2.bitwise_and(img, mask)
    if cropped:
        bbox = cv2.boundingRect(points)
        x, y, w, h = bbox
        imgCrop = img[y:y+h, x:x+w]
        imgCrop = cv2.resize(imgCrop, (0, 0), None, scale, scale)
        return imgCrop
    else:
        return mask

def process_image(img, landmark_choice, b, g, r):
    imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = detector(imgGray)

    imgOriginal = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  # Store a copy of the original image

    for face in faces:
        landmarks = predictor(imgGray, face)
        mypoints = []
        for n in range(0, 68):
            x = landmarks.part(n).x
            y = landmarks.part(n).y
            mypoints.append([x, y])
        mypoints = np.array(mypoints)

        imgLeftEye = createBox(img, mypoints[36:42], 3, masked=True, cropped=False)
        imgRightEye = createBox(img, mypoints[42:48], 3, masked=True, cropped=False)
        imgNose = createBox(img, mypoints[27:36], 3, masked=True, cropped=False)
        imgLips = createBox(img, mypoints[48:61], 3, masked=True, cropped=False)
        imgMouth = createBox(img, mypoints[48:68], 3, masked=True, cropped=False)

        if landmark_choice == 0:
            selected = imgLeftEye
            landmark_points = mypoints[36:42]
        elif landmark_choice == 1:
            selected = imgRightEye
            landmark_points = mypoints[42:48]
        elif landmark_choice == 2:
            selected = imgNose
            landmark_points = mypoints[27:36]
        elif landmark_choice == 3:
            selected = imgLips
            landmark_points = mypoints[48:61]
        elif landmark_choice == 4:
            selected = imgMouth
            landmark_points = mypoints[48:68]

        # Draw bounding box on the original image
        x, y, w, h = cv2.boundingRect(np.array(landmark_points))
        cv2.rectangle(imgOriginal, (x, y), (x + w, y + h), (0, 255, 0), 2)

        imgColorLandmark = np.zeros_like(selected)
        imgColorLandmark[:] = b, g, r
        imgColorLandmark = cv2.bitwise_and(imgColorLandmark, selected)
        imgColorLandmark = cv2.GaussianBlur(imgColorLandmark, (7, 7), 10)
        imgOriginalGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        imgOriginalGray = cv2.cvtColor(imgOriginalGray, cv2.COLOR_GRAY2BGR)
        imgColorLandmark = cv2.addWeighted(imgOriginalGray, 1, imgColorLandmark, 0.4, 0)

        imgGrayscale = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) 
        imgGrayscale = cv2.cvtColor(imgGrayscale, cv2.COLOR_GRAY2BGR)

        return imgColorLandmark, imgOriginal, imgGrayscale

def main():
    st.title("Facial Landmark Color Changer")

    # Create a sidebar
    st.sidebar.title("Options")

    # Upload image
    uploaded_file = st.sidebar.file_uploader("Choose an image", type=["jpg", "png"])

    if uploaded_file is not None:
        img = cv2.imdecode(np.frombuffer(uploaded_file.getvalue(), np.uint8), cv2.IMREAD_COLOR)

        # Display the uploaded image without changing the color space
        st.image(img, caption="Uploaded Image", channels="BGR", use_column_width=True)

        # Select landmark
        landmark_options = ["Left Eye", "Right Eye", "Nose", "Lips", "Mouth"]
        landmark_choice = st.sidebar.selectbox("Select a landmark", range(len(landmark_options)), format_func=lambda x: landmark_options[x])

        # Color sliders
        b = st.sidebar.slider("Red", 0, 255, 0)
        g = st.sidebar.slider("Green", 0, 255, 0)
        r = st.sidebar.slider("Blue", 0, 255, 0)

        # Process the image
        result, imgWithBox, imgGrayscale = process_image(img, landmark_choice, b, g, r)
        st.image(imgGrayscale, caption="Grayscale Image", use_column_width=True)
        st.image(imgWithBox, caption="Original Image with Bounding Box", use_column_width=True)

        # Display the results
        st.image(result, caption="Colored Landmark", use_column_width=True)
        st.download_button(
            label="Download Colored Landmark",
            data=cv2.imencode('.png', result)[1].tobytes(),
            file_name="colored_landmark.png",
            mime="image/png"
        )

if __name__ == "__main__":
    main()